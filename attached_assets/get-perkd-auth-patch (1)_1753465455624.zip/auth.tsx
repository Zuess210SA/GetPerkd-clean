
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { useSession } from '@supabase/auth-helpers-react';

const AuthPage = () => {
  const session = useSession();
  const router = useRouter();

  useEffect(() => {
    if (session) {
      const token = session?.access_token;
      if (token) {
        localStorage.setItem('supabase_token', token);
        router.push('/dashboard');
      }
    }
  }, [session]);

  // ... existing JSX
};

export default AuthPage;
