
export async function fetchWithToken(url: string, method = 'GET', body?: any) {
  const token = localStorage.getItem('supabase_token');

  const res = await fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
    },
    ...(body && { body: JSON.stringify(body) }),
  });

  if (res.status === 401) {
    console.error('🔒 Unauthorized! Token might be invalid.');
  }

  return res.json();
}
