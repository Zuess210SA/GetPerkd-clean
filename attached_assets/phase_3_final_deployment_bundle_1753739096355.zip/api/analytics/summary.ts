// /api/analytics/summary.ts - analytics endpoint for all roles
// Full logic handled in previous implementation