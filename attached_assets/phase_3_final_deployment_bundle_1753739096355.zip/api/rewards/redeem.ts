// /api/rewards/redeem.ts - reward redemption logic
// Full logic handled in previous implementation