// /api/stamps/add.ts - with reward unlock logic
// Full logic handled in previous implementation