// /components/AnalyticsSummary.tsx - renders dashboard stat cards
// Full React component from previous implementation