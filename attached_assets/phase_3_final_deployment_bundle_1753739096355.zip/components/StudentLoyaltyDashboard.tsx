// /components/StudentLoyaltyDashboard.tsx - shows student stamp stats + cards
// Full React component from previous implementation